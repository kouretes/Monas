#include "jointsliders.h"

JointSliders::JointSliders(Robot *robot, QWidget* parent):QWidget(parent)
{
    setUpWidget(robot);
}


void JointSliders::setUpWidget(Robot * robot){

    QGridLayout *glayout = new QGridLayout;

    for(int j = 0;j<2;j++){
        for(int i=0; i<robot->numOfJoints/2; i++){

                sliders.push_back(new sliderInput);

                glayout->addWidget(sliders[i+j*robot->numOfJoints/2],i,j);
                sliders[i+j*robot->numOfJoints/2]->setTitle(robot->joint[i+j*robot->numOfJoints/2]->jointName.c_str());
                sliders[i+j*robot->numOfJoints/2]->setStyleSheet("QGroupBox {"
                         "background-color: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,"
                         "stop: 0 #E0E0E0, stop: 1 " + QString(robot->joint[i+j*robot->numOfJoints/2]->jointColor.c_str()) +");"
                         "border: 2px solid gray;"
                         "border-radius: 5px;"
                         "margin-top: 1ex; }");

                sliders[i+j*robot->numOfJoints/2]->hSlider->setRange((int)(robot->joint[i]->bounds[0]*1000),(int)(robot->joint[i]->bounds[1]*1000));
                sliders[i+j*robot->numOfJoints/2]->hSlider->setValue((int)(0.5*(robot->joint[i]->bounds[0]*1000 + robot->joint[i]->bounds[1]*1000)));
                sliders[i+j*robot->numOfJoints/2]->hSlider->setSingleStep(1);


                sliders[i+j*robot->numOfJoints/2]->dblSpinBox->setRange((double)robot->joint[i]->bounds[0],(double)robot->joint[i]->bounds[1]);
                sliders[i+j*robot->numOfJoints/2]->dblSpinBox->setValue((double)(0.5* (robot->joint[i]->bounds[0]+robot->joint[i]->bounds[1])));
                sliders[i+j*robot->numOfJoints/2]->dblSpinBox->setSingleStep(0.01);

                //connect(sliders[i+j*robot->numOfJoints/2],SIGNAL(valueChanged(),this, SLOT(emitSliderValueChanged)));
            }
    }
    setLayout(glayout);
}

void JointSliders::emitSliderValueChanged(){



}
