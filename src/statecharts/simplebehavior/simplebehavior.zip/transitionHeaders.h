
#include "transitions/TrNode_0_1TOInit.h"
		
#include "transitions/TrNode_InitTOdecision_one_or_more_times_.h"
		
#include "transitions/TrNode_decision_one_or_more_times_TO0_4.h"
		
#include "transitions/TrNode_0_3_2_1TO0_3_2_2.h"
		
#include "transitions/TrNode_0_3_2_2TOplay.h"
		
#include "transitions/TrNode_0_3_2_2TONoPlay.h"
		
#include "transitions/TrNode_NoPlayTO0_3_2_5.h"
		
#include "transitions/TrNode_playTO0_3_2_5.h"
		
#include "transitions/TrNode_0_3_2_3_1TO0_3_2_3_2.h"
		
#include "transitions/TrNode_0_3_2_3_2TOAproachBall.h"
		
#include "transitions/TrNode_0_3_2_3_2TOkickBall.h"
		
#include "transitions/TrNode_0_3_2_3_2TOScanForBall.h"
		
#include "transitions/TrNode_ScanForBallTO0_3_2_3_6.h"
		
#include "transitions/TrNode_kickBallTO0_3_2_3_6.h"
		
#include "transitions/TrNode_AproachBallTO0_3_2_3_6.h"
		
#include "transitions/TrNode_0_3_2_3_4_1TO0_3_2_3_4_2.h"
		
#include "transitions/TrNode_0_3_2_3_4_2TOKickOff.h"
		
#include "transitions/TrNode_0_3_2_3_4_2TOkick.h"
		
#include "transitions/TrNode_kickTO0_3_2_3_4_5.h"
		
#include "transitions/TrNode_KickOffTO0_3_2_3_4_5.h"
		
#include "transitions/TrNode_0_3_2_3_4_4_1TO0_3_2_3_4_4_2.h"
		
#include "transitions/TrNode_0_3_2_3_4_4_2TOMyLeftKick.h"
		
#include "transitions/TrNode_0_3_2_3_4_4_2TOMyRightKick.h"
		
#include "transitions/TrNode_MyRightKickTO0_3_2_3_4_4_5.h"
		
#include "transitions/TrNode_MyLeftKickTO0_3_2_3_4_4_5.h"
		
#include "transitions/TrNode_0_3_1TOdecision.h"
		
#include "transitions/TrNode_decisionTOdecision.h"
		
#include "transitions/TrNode_decisionTO0_3_3.h"
		